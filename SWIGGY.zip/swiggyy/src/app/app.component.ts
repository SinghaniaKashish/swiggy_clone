import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { FavoritesComponent } from './favorites/favorites.component';
import { CartComponent } from './cart/cart.component';
import { SidebarComponent } from './sidebar/sidebar.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent, HomeComponent, FavoritesComponent, CartComponent, RouterLink, RouterLinkActive ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'swiggyy';

  onLinkClick(page: string) {
    console.log(`${page} link clicked`);
  }
  openSidebar() {
    const sidebar = document.querySelector('app-sidebar');
    sidebar?.classList.toggle('hidden');
  }
}
