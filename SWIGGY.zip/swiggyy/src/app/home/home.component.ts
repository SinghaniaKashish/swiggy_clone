import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { DishesComponent } from '../dishes/dishes.component';
import { FooterComponent } from '../footer/footer.component';
import { RestaurantsComponent } from "../restaurants/restaurants.component";
import { SidebarComponent } from "../sidebar/sidebar.component";

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [HeaderComponent, DishesComponent, FooterComponent, RestaurantsComponent, SidebarComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {

}
