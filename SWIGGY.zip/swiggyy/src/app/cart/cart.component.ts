import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { MenuItem } from '../services/menu.service';
import { HeaderComponent } from '../header/header.component';
import { SidebarComponent } from "../sidebar/sidebar.component";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [HeaderComponent, CommonModule, SidebarComponent],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
  cartItems: MenuItem[] = [];
  totalPrice: number = 0;
  orderPlaced: boolean = false;

  constructor(private cartService: CartService) {}

  ngOnInit(): void {
    this.loadCart();
  }

  private loadCart(): void {
    this.cartItems = this.cartService.getCartItems();
    this.calculateTotalPrice();
  }

  calculateTotalPrice(): void {
    this.totalPrice = this.cartItems.reduce((total, item) => total + item.price * (item.quantity || 1), 0);
  }

  increaseQuantity(item: MenuItem): void {
    item.quantity = (item.quantity || 1) + 1;
    this.calculateTotalPrice();
  }

  decreaseQuantity(item: MenuItem): void {
    if (item.quantity && item.quantity > 1) {
      item.quantity--;
      this.calculateTotalPrice();
    }
  }

  removeItem(item: MenuItem): void {
    this.cartService.removeItem(item);
    this.loadCart();
  }

  clearCart(): void {
    this.cartService.clearCart();
    this.loadCart();
  }

  placeOrder(): void {
    this.clearCart();
    this.orderPlaced = true;
  }
}
