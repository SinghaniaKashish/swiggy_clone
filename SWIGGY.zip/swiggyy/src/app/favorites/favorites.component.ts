import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { MenuItem } from '../services/menu.service';
import { FavoritesService } from '../services/favorites.service';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from "../sidebar/sidebar.component";
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-favorites',
  standalone: true,
  imports: [HeaderComponent, CommonModule, SidebarComponent],
  templateUrl: './favorites.component.html',
  styleUrl: './favorites.component.scss'
})


export class FavoritesComponent {
  favoriteItems: MenuItem[] = [];

  menuItems: MenuItem[] = [];

  showWarning = false;
  selectedItem: MenuItem | null = null;

  constructor(private favoriteService: FavoritesService,
    private cartService: CartService
  ) {}

  ngOnInit() {
    this.favoriteItems = this.favoriteService.getFavorites();
  }

  removeFavorite(item: MenuItem) {
    this.favoriteService.removeFavorite(item);
    this.favoriteItems = this.favoriteService.getFavorites(); 
  }


  addToCart(item: MenuItem) {
    if (this.cartService.addToCart(item)) {
      this.showWarning = false;
    } else {
      this.selectedItem = item;
      this.showWarning = true;
    }
  }

  clearCartAndAdd() {
    if (this.selectedItem) {
      this.cartService.clearCart();
      this.cartService.addToCart(this.selectedItem);
      this.selectedItem = null;
      this.showWarning = false;
    }
  }

  cancelAdd() {
    this.selectedItem = null;
    this.showWarning = false;
  }

}
