import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dishes',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dishes.component.html',
  styleUrl: './dishes.component.scss'
})
export class DishesComponent {
  dishes = [
    "../../assets/dishes/biryani.avif",
    "../../assets/dishes/pizzas.avif",
    "../../assets/dishes/burgers.avif",
    "../../assets/dishes/coffee.avif",
    "../../assets/dishes/cakes.avif",
    "../../assets/dishes/khichdi.avif",
    "../../assets/dishes/rasgulla.avif",
    "../../assets/dishes/chhole.avif",
    "../../assets/dishes/cutlet.avif",
    "../../assets/dishes/lassi.avif",
    "../../assets/dishes/rolls.avif",
  ]
}
