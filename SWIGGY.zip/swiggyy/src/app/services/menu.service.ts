import { Injectable } from '@angular/core';

export interface MenuItem {
  id: number;
  restaurantId: number;
  name: string;
  description: string;
  price: number;
  cuisine: string;
  veg: boolean,
  img: string,
  quantity?: number;
}

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private menuItems: MenuItem[] = [
    // Dominos
  { id: 1, restaurantId: 1, name: 'Margherita Pizza', description: 'Classic cheese pizza', price: 200, cuisine: 'Italian', veg: true, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 2, restaurantId: 1, name: 'Pepperoni Pizza', description: 'Topped with pepperoni', price: 250, cuisine: 'Italian', veg: false, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 3, restaurantId: 1, name: 'Garlic Breadsticks', description: 'Crispy and garlicky breadsticks', price: 100, cuisine: 'Italian', veg: true, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 4, restaurantId: 1, name: 'Veggie Supreme Pizza', description: 'Loaded with fresh vegetables', price: 220, cuisine: 'Italian', veg: true, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 5, restaurantId: 1, name: 'Chicken Tikka Pizza', description: 'Topped with spicy chicken tikka', price: 240, cuisine: 'Italian', veg: false, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 6, restaurantId: 1, name: 'Cheesy Dip', description: 'Perfect dip for pizzas', price: 30, cuisine: 'Italian', veg: true, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 7, restaurantId: 1, name: 'Paneer Pizza', description: 'Pizza topped with paneer cubes', price: 230, cuisine: 'Italian', veg: true, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 8, restaurantId: 1, name: 'Spicy Chicken Wings', description: 'Crispy chicken wings', price: 180, cuisine: 'Italian', veg: false, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 9, restaurantId: 1, name: 'Stuffed Garlic Bread', description: 'Stuffed with corn and cheese', price: 120, cuisine: 'Italian', veg: true, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },
  { id: 10, restaurantId: 1, name: 'Tandoori Paneer Pizza', description: 'Tandoori-flavored paneer', price: 250, cuisine: 'Italian', veg: true, img: '../../../assets/restaurants/dominos/peppypaneer.avif' },

  // KFC
  { id: 11, restaurantId: 2, name: 'Zinger Burger', description: 'Crispy fried chicken burger', price: 150, cuisine: 'American', veg: false, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 12, restaurantId: 2, name: 'Chicken Popcorn', description: 'Bite-sized chicken pieces', price: 120, cuisine: 'American', veg: false, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 13, restaurantId: 2, name: 'Hot Wings', description: 'Spicy chicken wings', price: 180, cuisine: 'American', veg: false, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 14, restaurantId: 2, name: 'Crispy Chicken Bucket', description: 'Bucket of fried chicken pieces', price: 450, cuisine: 'American', veg: false, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 15, restaurantId: 2, name: 'Veg Zinger Burger', description: 'Crispy veggie patty burger', price: 130, cuisine: 'American', veg: true, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 16, restaurantId: 2, name: 'French Fries', description: 'Golden crispy fries', price: 80, cuisine: 'American', veg: true, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 17, restaurantId: 2, name: 'Rice Bowl', description: 'Rice with fried chicken', price: 160, cuisine: 'American', veg: false, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 18, restaurantId: 2, name: 'Peri Peri Fries', description: 'Spicy flavored fries', price: 90, cuisine: 'American', veg: true, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 19, restaurantId: 2, name: 'Chicken Strips', description: 'Crispy chicken strips', price: 140, cuisine: 'American', veg: false, img: '../../../assets/restaurants/kfc/vegmeal.avif' },
  { id: 20, restaurantId: 2, name: 'Chicken Wrap', description: 'Wrap with chicken filling', price: 170, cuisine: 'American', veg: false, img: '../../../assets/restaurants/kfc/vegmeal.avif' },

  // Wow Momo
  { id: 21, restaurantId: 3, name: 'Veg Momos', description: 'Steamed vegetable momos', price: 90, cuisine: 'Tibetan', veg: true, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 22, restaurantId: 3, name: 'Chicken Momos', description: 'Steamed chicken momos', price: 120, cuisine: 'Tibetan', veg: false, img: '../../../assets/restaurants/wowmomo/wowmomo.avif' },
  { id: 23, restaurantId: 3, name: 'Prawn Momos', description: 'Steamed prawn momos', price: 150, cuisine: 'Tibetan', veg: false, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 24, restaurantId: 3, name: 'Chocolate Momos', description: 'Sweet chocolate-filled momos', price: 100, cuisine: 'Tibetan', veg: true, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 25, restaurantId: 3, name: 'Fried Veg Momos', description: 'Fried vegetable momos', price: 100, cuisine: 'Tibetan', veg: true, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 26, restaurantId: 3, name: 'Fried Chicken Momos', description: 'Fried chicken momos', price: 130, cuisine: 'Tibetan', veg: false, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 27, restaurantId: 3, name: 'Tandoori Momos', description: 'Tandoori spiced momos', price: 120, cuisine: 'Tibetan', veg: true, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 28, restaurantId: 3, name: 'Cheese Momos', description: 'Momos with cheese filling', price: 110, cuisine: 'Tibetan', veg: true, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 29, restaurantId: 3, name: 'Veg Kothe', description: 'Pan-fried momos', price: 100, cuisine: 'Tibetan', veg: true, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },
  { id: 30, restaurantId: 3, name: 'Chicken Kothe', description: 'Pan-fried chicken momos', price: 130, cuisine: 'Tibetan', veg: false, img: '../../../assets/restaurants/wowmomo/corncheesemomo.avif' },

  // Oberai Bekar & Cafe
  { id: 31, restaurantId: 4, name: 'Blueberry Muffin', description: 'Freshly baked muffin', price: 80, cuisine: 'Bakery', veg: true, img: '../../../assets/restaurants/wowchina/vegroll.avif' },
  { id: 32, restaurantId: 4, name: 'Cappuccino', description: 'Rich and creamy coffee', price: 100, cuisine: 'Cafe', veg: true, img: 'cappuccino.jpg' },
  { id: 33, restaurantId: 4, name: 'Chocolate Croissant', description: 'Buttery croissant with chocolate', price: 90, cuisine: 'Bakery', veg: true, img: 'chocolatecroissant.jpg' },
  { id: 34, restaurantId: 4, name: 'Apple Pie', description: 'Classic apple pie slice', price: 110, cuisine: 'Bakery', veg: true, img: 'applepie.jpg' },
  { id: 35, restaurantId: 4, name: 'Bagel with Cream Cheese', description: 'Toasted bagel with cream cheese', price: 70, cuisine: 'Cafe', veg: true, img: 'bagel.jpg' },
  { id: 36, restaurantId: 4, name: 'Espresso', description: 'Strong espresso shot', price: 60, cuisine: 'Cafe', veg: true, img: 'espresso.jpg' },
  { id: 37, restaurantId: 4, name: 'Latte', description: 'Smooth latte coffee', price: 120, cuisine: 'Cafe', veg: true, img: 'latte'},

  // Hotel Priya
  { id: 41, restaurantId: 5, name: 'Vegetable Biryani', description: 'Aromatic rice with vegetables', price: 180, cuisine: 'Indian', veg: true, img: 'vegetablebiryani.jpg' },
  { id: 42, restaurantId: 5, name: 'Chicken Biryani', description: 'Flavorful rice with chicken', price: 220, cuisine: 'Indian', veg: false, img: 'chickenbiryani.jpg' },
  { id: 43, restaurantId: 5, name: 'Paneer Butter Masala', description: 'Paneer cooked in creamy butter gravy', price: 160, cuisine: 'Indian', veg: true, img: 'paneerbuttermasala.jpg' },
  { id: 44, restaurantId: 5, name: 'Tandoori Chicken', description: 'Marinated chicken grilled to perfection', price: 250, cuisine: 'Indian', veg: false, img: 'tandoorichicken.jpg' },
  { id: 45, restaurantId: 5, name: 'Chole Bhature', description: 'Spicy chickpeas served with fluffy bread', price: 150, cuisine: 'Indian', veg: true, img: 'cholebhature.jpg' },
  { id: 46, restaurantId: 5, name: 'Mutton Rogan Josh', description: 'Slow-cooked mutton in rich gravy', price: 280, cuisine: 'Indian', veg: false, img: 'muttonroganjosh.jpg' },
  { id: 47, restaurantId: 5, name: 'Aloo Paratha', description: 'Stuffed potato flatbread', price: 120, cuisine: 'Indian', veg: true, img: 'alooparatha.jpg' },
  { id: 48, restaurantId: 5, name: 'Gulab Jamun', description: 'Sweet syrup-soaked dumplings', price: 80, cuisine: 'Indian', veg: true, img: 'gulabjamun.jpg' },
  { id: 49, restaurantId: 5, name: 'Dahi Puri', description: 'Crispy puris topped with yogurt', price: 100, cuisine: 'Indian', veg: true, img: 'dahipuri.jpg' },
  { id: 50, restaurantId: 5, name: 'Butter Naan', description: 'Soft, buttery flatbread', price: 40, cuisine: 'Indian', veg: true, img: 'butternaan.jpg' },

  // Hotel Venus
  { id: 51, restaurantId: 6, name: 'Veg Fried Rice', description: 'Rice stir-fried with vegetables', price: 150, cuisine: 'Chinese', veg: true, img: 'vegfriedrice.jpg' },
  { id: 52, restaurantId: 6, name: 'Chicken Fried Rice', description: 'Rice stir-fried with chicken', price: 180, cuisine: 'Chinese', veg: false, img: 'chickenfriedrice.jpg' },
  { id: 53, restaurantId: 6, name: 'Spring Rolls', description: 'Crispy rolls stuffed with vegetables', price: 120, cuisine: 'Chinese', veg: true, img: 'springrolls.jpg' },
  { id: 54, restaurantId: 6, name: 'Chili Chicken', description: 'Spicy chicken stir-fried with vegetables', price: 220, cuisine: 'Chinese', veg: false, img: 'chilichicken.jpg' },
  { id: 55, restaurantId: 6, name: 'Hot and Sour Soup', description: 'Spicy and tangy soup with vegetables', price: 90, cuisine: 'Chinese', veg: true, img: 'hotsoursoup.jpg' },
  { id: 56, restaurantId: 6, name: 'Sweet and Sour Chicken', description: 'Chicken in a tangy sauce', price: 210, cuisine: 'Chinese', veg: false, img: 'sweetandsourchicken.jpg' },
  { id: 57, restaurantId: 6, name: 'Steamed Momos', description: 'Steamed dumplings with filling', price: 100, cuisine: 'Chinese', veg: true, img: 'steamedmomos.jpg' },
  { id: 58, restaurantId: 6, name: 'Szechuan Noodles', description: 'Spicy noodles stir-fried with vegetables', price: 180, cuisine: 'Chinese', veg: true, img: 'szechuannoodles.jpg' },
  { id: 59, restaurantId: 6, name: 'Chicken Manchurian', description: 'Spicy chicken with Manchurian sauce', price: 220, cuisine: 'Chinese', veg: false, img: 'chickenmanchurian.jpg' },
  { id: 60, restaurantId: 6, name: 'Fried Wantons', description: 'Crispy dumplings stuffed with vegetables', price: 110, cuisine: 'Chinese', veg: true, img: 'friedwantons.jpg' },

  // Kake Da Minar
  { id: 61, restaurantId: 7, name: 'Chicken Shawarma', description: 'Grilled chicken with spices in a wrap', price: 150, cuisine: 'Middle Eastern', veg: false, img: 'chickenshawarma.jpg' },
  { id: 62, restaurantId: 7, name: 'Hummus with Pita Bread', description: 'Creamy hummus served with pita bread', price: 130, cuisine: 'Middle Eastern', veg: true, img: 'hummuswithpita.jpg' },
  { id: 63, restaurantId: 7, name: 'Falafel', description: 'Deep-fried chickpea balls', price: 100, cuisine: 'Middle Eastern', veg: true, img: 'falafel.jpg' },
  { id: 64, restaurantId: 7, name: 'Mutton Kebab', description: 'Grilled mutton with spices', price: 220, cuisine: 'Middle Eastern', veg: false, img: 'muttonkebab.jpg' },
  { id: 65, restaurantId: 7, name: 'Shish Tawook', description: 'Grilled chicken skewers', price: 180, cuisine: 'Middle Eastern', veg: false, img: 'shishtawook.jpg' },
  { id: 66, restaurantId: 7, name: 'Tabbouleh', description: 'Salad with parsley, tomatoes, and lemon', price: 120, cuisine: 'Middle Eastern', veg: true, img: 'tabbouleh.jpg' },
  { id: 67, restaurantId: 7, name: 'Baklava', description: 'Sweet pastry with nuts and syrup', price: 80, cuisine: 'Middle Eastern', veg: true, img: 'baklava.jpg' },
  { id: 68, restaurantId: 7, name: 'Lentil Soup', description: 'Spicy lentil soup', price: 90, cuisine: 'Middle Eastern', veg: true, img: 'lentilsoup.jpg' },
  { id: 69, restaurantId: 7, name: 'Chicken Shawarma Plate', description: 'Chicken shawarma with salad and rice', price: 230, cuisine: 'Middle Eastern', veg: false, img: 'shawarmaplate.jpg' },
  { id: 70, restaurantId: 7, name: 'Kebab Plate', description: 'Grilled kebabs served with rice', price: 250, cuisine: 'Middle Eastern', veg: false, img: 'kebabplate.jpg' },

  // Wow China
  { id: 71, restaurantId: 8, name: 'Veg Manchurian', description: 'Crispy vegetable balls in a spicy sauce', price: 140, cuisine: 'Chinese', veg: true, img: '../../../assets/restaurants/wowchina/vegroll.avif' },
  { id: 72, restaurantId: 8, name: 'Gobi Manchurian', description: 'Crispy cauliflower in a tangy sauce', price: 150, cuisine: 'Chinese', veg: true, img: '../../../assets/restaurants/wowchina/vegroll.avif' },
  { id: 73, restaurantId: 8, name: 'Chilli Paneer', description: 'Paneer cubes in spicy sauce', price: 160, cuisine: 'Chinese', veg: true, img: '../../../assets/restaurants/wowchina/vegroll.avif' },
  { id: 74, restaurantId: 8, name: 'Honey Chilli Potato', description: 'Sweet and spicy fried potatoes', price: 130, cuisine: 'Chinese', veg: true, img: '../../../assets/restaurants/wowchina/vegroll.avif' },
  { id: 75, restaurantId: 8, name: 'Veg Hakka Noodles', description: 'Stir-fried noodles with vegetables', price: 180, cuisine: 'Chinese', veg: true, img: '../../../assets/restaurants/wowchina/vegroll.avif' },

  ];

  getMenuItemsByRestaurantId(restaurantId: number): MenuItem[] {
    return this.menuItems.filter(item => item.restaurantId === restaurantId);
  }

  // constructor() { }
}
