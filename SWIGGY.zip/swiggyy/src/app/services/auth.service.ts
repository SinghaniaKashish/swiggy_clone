import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { tap, switchMap, catchError } from 'rxjs/operators';

interface User {
  id: number;
  phone: string;
  password: string;
  cart: any[];
  favorites: any[];
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'https://672cca1dfd89797156403385.mockapi.io/login'; 

  constructor(private http: HttpClient) {}

  
  login(phone: string, password: string): Observable<User> {
    return this.http.get<User[]>(`${this.apiUrl}?phone=${phone}`).pipe(
      switchMap(users => {
        if (users && users.length > 0) {

          const user = users.find(u => u.password === password);
          if (user) {
            this.storeUserData(user);
            return of(user); 
          } else {
            return throwError(() => new Error('Incorrect password'));
          }
        } else {
          return this.register(phone, password);
        }
      }),
      catchError((error: HttpErrorResponse) => {
        if (error.status === 404) {
          return this.register(phone, password);
        }
        console.error('Login/Registration Error:', error);
        return throwError(() => new Error('Login failed. Please try again later.'));
      })
    );
  }


  private register(phone: string, password: string): Observable<User> {
    const newUser: User = {
      id: Date.now(),  
      phone,
      password,
      cart: [],
      favorites: []
    };

    return this.http.post<User>(this.apiUrl, newUser).pipe(
      tap(user => {
        console.log('User registered:', user);
        this.storeUserData(user); 
      }),
      catchError(error => {
        console.error('Registration failed:', error);
        return throwError(() => new Error('Registration failed. Please try again.'));
      })
    );
  }

  
  getCurrentUser(): User | null {
    const userData = localStorage.getItem('user');
    return userData ? JSON.parse(userData) : null;
  }

  
  logout(): void {
    console.log('Logging out user...');
    localStorage.removeItem('user'); 
  }

  private storeUserData(user: User) {
    localStorage.setItem('user', JSON.stringify(user)); 
    console.log('User data stored in localStorage:', user);
  }
}
