import { Injectable } from '@angular/core';
import { MenuItem } from './menu.service';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartItems: MenuItem[] = [];
  private currentRestaurantId: number | null = null;

  getCartItems(): MenuItem[] {
    return this.cartItems;
  }

  addToCart(item: MenuItem): boolean {
    if (this.cartItems.length > 0 && this.currentRestaurantId !== item.restaurantId) {
      return false;
    }

    const existingItem = this.cartItems.find(cartItem => cartItem.id === item.id);
    if (existingItem) {
      existingItem.quantity = (existingItem.quantity || 1) + 1;
    } else {
      this.cartItems.push({ ...item, quantity: 1 });
      this.currentRestaurantId = item.restaurantId;
    }

    return true;
  }

  removeItem(item: MenuItem): void {
    this.cartItems = this.cartItems.filter(cartItem => cartItem.id !== item.id);
    if (this.cartItems.length === 0) {
      this.currentRestaurantId = null;
    }
  }

  clearCart(): void {
    this.cartItems = [];
    this.currentRestaurantId = null;
  }
}

