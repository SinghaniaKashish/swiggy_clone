import { Injectable } from '@angular/core';

export interface Restaurant {
  id: number;
  name: string;
  cuisine: string[];
  location: string;
  img: string;
}

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  private restaurants: Restaurant[] = [
    { id: 1, name: 'Dominos', cuisine: ['Italian', 'Fast Food'], location: 'Bhubaneswar', img: '../../../assets/restaurants/dominos/dominos.avif' },
    { id: 2, name: 'KFC', cuisine: ['American', 'Fast Food'], location: 'Bhubaneswar', img: '../../../assets/restaurants/kfc/kfc.avif' },
    { id: 3, name: 'Wow! Momo', cuisine: ['Tibetan', 'Chinese'], location: 'Bhubaneswar', img: '../../../assets/restaurants/wowmomo/wowmomo.avif' },
    { id: 8, name: 'Wow! China', cuisine: ['Chinese'], location: 'Bhubaneswar', img: '../../../assets/restaurants/wowchina/wowchina.jpeg' },
    { id: 4, name: 'Oberai Bekar & Cafe', cuisine: ['Bakery', 'Cafe'], location: 'Bhubaneswar', img: '../../../assets/restaurants/oberai/oberai.avif' },
    { id: 5, name: 'Hotel Priya', cuisine: ['Indian', 'South Indian'], location: 'Bhubaneswar', img: '../../../assets/restaurants/priya/priya.jpeg' },
    { id: 6, name: 'Hotel Venus', cuisine: ['Indian', 'Chinese'], location: 'Bhubaneswar', img: '../../../assets/restaurants/venus/venus.jpeg' },
    { id: 7, name: 'Kake Da Minar', cuisine: ['Punjabi', 'North Indian'], location: 'Bhubaneswar', img: '../../../assets/restaurants/kakedaminar/kakedaminar.jpeg' }
    
  ];

  getRestaurants(): Restaurant[] {
    return this.restaurants;
  }

  getRestaurantById(id: number): Restaurant | undefined {
    return this.restaurants.find(restaurant => restaurant.id === id);
  }
  constructor() { }
}
