import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { SidebarService } from '../sidebar.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit, OnDestroy {
  isOpen: boolean = false;
  private subscription!: Subscription;
  phone = '';
  password = '';
  isLogin = true;
  message = ''; 
  messageType: 'success' | 'error' = 'success';  

  constructor(
    private sidebarService: SidebarService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.subscription = this.sidebarService.isSidebarOpen$.subscribe(isOpen => {
      this.isOpen = isOpen;
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  closeSidebar() {
    this.sidebarService.closeSidebar();
    this.clearForm(); 
  }

  toggleMode() {
    this.isLogin = !this.isLogin;
    this.message = '';  
  }

  handleSubmit() {
    this.message = '';  
    console.log('Phone:', this.phone);
    console.log('Password:', this.password);
  
    this.authService.login(this.phone, this.password).subscribe(
      (user) => {
        if (this.isLogin) {
          this.message = 'Successfully logged in!';
          this.messageType = 'success';
        } else {
          this.message = 'Successfully signed up!';
          this.messageType = 'success';
        }
        console.log('User logged in :', user);
      },
      (error) => {
        console.error('Login failed:', error);
        this.message = error.message === 'Incorrect password' ? 
          'Incorrect password. Please try again.' : 
          'Login failed. Please try again later.';
        this.messageType = 'error';
      }
    );
  }
  
  private clearForm() {
    this.phone = '';
    this.password = '';
    this.message = '';
  }
}

